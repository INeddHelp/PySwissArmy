from setuptools import setup

setup(
    name='PySwissArmy',
    version='0.1.0',
    description='PyBox is a Python utility library designed to make common programming tasks easier.',
    author='INeddHelp',
    author_email='ineddhelpgithub@gmail.com',
    packages=['pyswissarmy']
)
